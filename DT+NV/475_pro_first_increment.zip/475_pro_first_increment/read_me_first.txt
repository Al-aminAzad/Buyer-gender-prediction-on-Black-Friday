1. run the '1.0_malnutrition_preprocessing_visualize' file
2. run the '1.3_apply_classification_algo' file